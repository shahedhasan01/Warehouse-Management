﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace warehouse_management
{
    public partial class menu : System.Web.UI.Page
    {
        SqlConnection con = null;


        protected void Page_Load(object sender, EventArgs e)
        {
 
        }

         

        protected void logout_Click(object sender, EventArgs e)
        {
            Server.Transfer("login.aspx");
        }
         

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                string strCon = "Data Source=DESKTOP-FP8P4U0\\SQLEXPRESS;Initial Catalog=workerdata;Integrated Security=True ";
                 con = new SqlConnection(strCon);
                con.Open();
            }
            catch (Exception)
            {
                throw ;
            }
            //WORKENTRY IS TABLE NAME
            SqlCommand cmd = new SqlCommand("insert into pstore(Id,Name,Storedate,Timelimit,Quantity,Paid,Address,Phone) values (@id,@name,@storedate,@timelimit,@quantity,@paid,@address,@phone)", con);
                cmd.Parameters.AddWithValue("@id", stb1.Text);
                cmd.Parameters.AddWithValue("@name", stb2.Text);
                cmd.Parameters.AddWithValue("@storedate", stb3.Text);
                cmd.Parameters.AddWithValue("@timelimit", stb4.Text);
                cmd.Parameters.AddWithValue("@quantity", stb5.Text);
                cmd.Parameters.AddWithValue("@paid", stb6.Text);
                cmd.Parameters.AddWithValue("@Address", stb7.Text);
                cmd.Parameters.AddWithValue("@phone", stb8.Text);

                cmd.ExecuteNonQuery();
                con.Close();
        }

        

        protected void Button2_Click(object sender, EventArgs e)
        {
            FileUpload1.SaveAs(Server.MapPath("Uploads\\" + FileUpload1.FileName));

        }
    }
}
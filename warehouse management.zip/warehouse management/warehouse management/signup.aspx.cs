﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace warehouse_management
{
    public partial class Login : System.Web.UI.Page
    {


        SqlConnection con = null;

       


        protected void submitbutton_Click(object sender, EventArgs e)
        {

            try
            {
                string strCon = "Data Source=DESKTOP-FP8P4U0\\SQLEXPRESS;Initial Catalog=workerdata;Integrated Security=True ";
                con = new SqlConnection(strCon);
                con.Open();

            }
            catch (Exception )
            {
                throw;
            }
            //WORKENTRY IS TABLE NAME
            SqlCommand cmd = new SqlCommand("insert into workentry (id,password,position) values (@Id,@Pass,@position)", con);
            cmd.Parameters.AddWithValue("@Id", txtid.Text);
            cmd.Parameters.AddWithValue("@Pass", txtpassword.Text);
            cmd.Parameters.AddWithValue("@position", txtposition.Text);


            cmd.ExecuteNonQuery();
            con.Close();


        }

        

        protected void Log_Click1(object sender, EventArgs e)
        {
            Server.Transfer("login.aspx");
        }
    }
}
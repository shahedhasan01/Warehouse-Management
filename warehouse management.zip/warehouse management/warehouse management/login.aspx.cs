﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace warehouse_management
{
    public partial class login : System.Web.UI.Page

    {

        SqlConnection con = new SqlConnection("Data Source=DESKTOP-FP8P4U0\\SQLEXPRESS;Initial Catalog=workerdata;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Clear();
            }
        }

        private void Clear()
        {
            logid.Text = logpass.Text = "";
        }

        protected void loginbtn_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                //query sql

                SqlCommand cmd = new SqlCommand("Select * From workentry where id='" + logid.Text + "' and  password= '" + logpass.Text + "' ", con);
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {

                    Server.Transfer("main.aspx");
 
                }
                else
                {
                    Response.Write(" Wrong Login_info,Please Try Again.");   

                }

            }
            finally
            {

                con.Close();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Write("Please contact with office!");


        }
        protected void b2_Click(object sender, EventArgs e)
        {
            Server.Transfer("signup.aspx");


        }

        protected void b2_Click1(object sender, EventArgs e)
        {
             Server.Transfer("signup.aspx");
        }
    }
}

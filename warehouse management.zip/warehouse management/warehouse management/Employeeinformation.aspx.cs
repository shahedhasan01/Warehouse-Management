﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace warehouse_management
{
    public partial class Employeeinformation : System.Web.UI.Page
    {

        SqlConnection con = null;
 
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            try
            {
                string strCon = "Data Source=DESKTOP-FP8P4U0\\SQLEXPRESS;Initial Catalog=workerdata;Integrated Security=True ";
                con = new SqlConnection(strCon);
                con.Open();
            }
            catch (Exception)
            {
                throw;
            }
             
            SqlCommand cmd = new SqlCommand("insert into employeinfo(Id,Nama,Age,Position,Salary,Mobile,Address ) values (@id,@name,@age,@position,@salary,@mobile,@address)", con);
            cmd.Parameters.AddWithValue("@id", stb1.Text);
            cmd.Parameters.AddWithValue("@name", stb2.Text);
            cmd.Parameters.AddWithValue("@age", stb3.Text);
            cmd.Parameters.AddWithValue("@position", stb4.Text);
            cmd.Parameters.AddWithValue("@salary", stb5.Text);
            cmd.Parameters.AddWithValue("@mobile", stb6.Text);
            cmd.Parameters.AddWithValue("@Address", stb7.Text);


            cmd.ExecuteNonQuery();
            con.Close();
        }

        

         

        protected void Button4_Click1(object sender, EventArgs e)
        {
            FileUpload1.SaveAs(Server.MapPath("img\\" + FileUpload1.FileName));

        }
    }
}